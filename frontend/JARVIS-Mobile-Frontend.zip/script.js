const form = document.getElementById("command-form");
const input = document.getElementById("msg");
const chat = document.getElementById("chat");
const micButton = document.getElementById("mic");
const voiceToggle = document.getElementById("voice-toggle");
const voiceStatus = document.getElementById("voice-status");
const voiceHint = document.getElementById("voice-hint");
const coreStatus = document.getElementById("core-status");

let voiceEnabled = true;
let recognition = null;

function addMessage(text, type = "assistant") {
  const message = document.createElement("div");
  message.className = `message ${type === "user" ? "user-message" : "assistant-message"}`;
  message.textContent = text;
  chat.appendChild(message);
  chat.scrollTop = chat.scrollHeight;
  return message;
}

function getDemoReply(command) {
  const value = command.toLowerCase();
  if (value.includes("hello") || value.includes("hi")) return "Hello! Systems are online. How may I help you?";
  if (value.includes("time")) return `The current time is ${new Date().toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"})}.`;
  if (value.includes("date")) return `Today's date is ${new Date().toLocaleDateString()}.`;
  if (value.includes("who are you")) return "I am J.A.R.V.I.S., your personal assistant interface.";
  return "Command received. Your frontend is working. Connect your AI backend in script.js to receive intelligent responses.";
}

function speak(text) {
  if (!voiceEnabled || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.rate = 1;
  utterance.pitch = 0.95;
  window.speechSynthesis.speak(utterance);
}

function sendCommand(command) {
  const clean = command.trim();
  if (!clean) return;
  addMessage(clean, "user");
  input.value = "";
  coreStatus.textContent = "PROCESSING COMMAND";
  const pending = addMessage("Processing your command...");
  window.setTimeout(() => {
    const reply = getDemoReply(clean);
    pending.textContent = reply;
    coreStatus.textContent = "AWAITING YOUR COMMAND";
    speak(reply);
  }, 450);
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  sendCommand(input.value);
});

function setupSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    voiceHint.textContent = "VOICE INPUT NOT SUPPORTED IN THIS BROWSER";
    voiceStatus.textContent = "UNAVAILABLE";
    micButton.disabled = true;
    micButton.title = "Voice recognition is not supported in this browser";
    return;
  }

  recognition = new SpeechRecognition();
  recognition.lang = "en-IN";
  recognition.interimResults = false;
  recognition.continuous = false;

  recognition.onstart = () => {
    micButton.classList.add("listening");
    voiceHint.textContent = "LISTENING — SPEAK NOW";
    coreStatus.textContent = "VOICE INPUT ACTIVE";
  };
  recognition.onresult = (event) => {
    input.value = event.results[0][0].transcript;
    sendCommand(input.value);
  };
  recognition.onerror = (event) => {
    voiceHint.textContent = event.error === "not-allowed" ? "MICROPHONE PERMISSION DENIED" : "VOICE INPUT ERROR — TRY AGAIN";
  };
  recognition.onend = () => {
    micButton.classList.remove("listening");
    if (voiceEnabled) voiceHint.textContent = "VOICE SYSTEM READY";
    coreStatus.textContent = "AWAITING YOUR COMMAND";
  };
}

micButton.addEventListener("click", () => {
  if (!recognition) {
    setupSpeechRecognition();
    if (!recognition) return;
  }
  try {
    recognition.start();
  } catch (error) {
    voiceHint.textContent = "VOICE INPUT IS ALREADY ACTIVE";
  }
});

voiceToggle.addEventListener("click", () => {
  voiceEnabled = !voiceEnabled;
  voiceToggle.classList.toggle("off", !voiceEnabled);
  voiceToggle.querySelector("span").textContent = voiceEnabled ? "VOICE ON" : "VOICE OFF";
  voiceStatus.textContent = voiceEnabled ? "READY" : "MUTED";
  voiceHint.textContent = voiceEnabled ? "VOICE SYSTEM READY" : "VOICE OUTPUT MUTED";
  if (!voiceEnabled && "speechSynthesis" in window) window.speechSynthesis.cancel();
});

setupSpeechRecognition();

// Replace getDemoReply() with your backend/API request when you are ready
// to connect the actual JARVIS AI engine. Do not publish a private API key
// directly in this frontend; keep secret keys on a server.
